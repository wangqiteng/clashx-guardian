﻿IKuuu Guardian 0.1.8 Windows x64
修复托盘菜单行距过大、失焦不关闭的问题。
完整解压后运行 IKuuuGuardian.exe。
